import { jsPDF } from 'jspdf'

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export function getSvgElementById(id: string): SVGSVGElement | null {
  const el = document.getElementById(id)
  if (!el) return null
  if (el instanceof SVGSVGElement) return el
  // if wrapper div contains svg
  const svg = el.querySelector('svg')
  return svg as any
}

export function serializeSvg(svg: SVGSVGElement): string {
  const clone = svg.cloneNode(true) as SVGSVGElement
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg')
  clone.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink')

  const s = new XMLSerializer().serializeToString(clone)
  // Ensure white background
  const withBg = s.replace('<svg', '<svg')
  return withBg
}

export async function exportPngFromSvg(svg: SVGSVGElement, filename = 'diagram.png', scale = 3) {
  const svgText = serializeSvg(svg)
  const blob = new Blob([svgText], { type: 'image/svg+xml;charset=utf-8' })
  const url = URL.createObjectURL(blob)

  const img = new Image()
  img.decoding = 'async'
  const loaded = new Promise<void>((resolve, reject) => {
    img.onload = () => resolve()
    img.onerror = () => reject(new Error('Cannot load SVG image'))
  })
  img.src = url
  await loaded
  URL.revokeObjectURL(url)

  const w = svg.viewBox.baseVal && svg.viewBox.baseVal.width ? svg.viewBox.baseVal.width : svg.clientWidth
  const h = svg.viewBox.baseVal && svg.viewBox.baseVal.height ? svg.viewBox.baseVal.height : svg.clientHeight

  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.floor(w * scale))
  canvas.height = Math.max(1, Math.floor(h * scale))
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

  const pngBlob: Blob = await new Promise((resolve) => canvas.toBlob(b => resolve(b!), 'image/png') as any)
  downloadBlob(pngBlob, filename)
}

export async function exportPdfFromSvg(svg: SVGSVGElement, filename = 'diagram.pdf') {
  // raster-based but high quality
  const svgText = serializeSvg(svg)
  const blob = new Blob([svgText], { type: 'image/svg+xml;charset=utf-8' })
  const url = URL.createObjectURL(blob)

  const img = new Image()
  img.decoding = 'async'
  const loaded = new Promise<void>((resolve, reject) => {
    img.onload = () => resolve()
    img.onerror = () => reject(new Error('Cannot load SVG image'))
  })
  img.src = url
  await loaded
  URL.revokeObjectURL(url)

  const w = svg.clientWidth || 900
  const h = svg.clientHeight || 600

  const canvas = document.createElement('canvas')
  const scale = 3
  canvas.width = Math.floor(w * scale)
  canvas.height = Math.floor(h * scale)
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

  const dataUrl = canvas.toDataURL('image/png')
  const pdf = new jsPDF({
    orientation: w >= h ? 'landscape' : 'portrait',
    unit: 'pt',
    format: [w, h]
  })
  pdf.addImage(dataUrl, 'PNG', 0, 0, w, h)
  pdf.save(filename)
}

export async function exportWordHtmlFromSvg(svg: SVGSVGElement, filename = 'diagram.doc') {
  // Word can open HTML-as-DOC. This is a pragmatic MVP exporter.
  const svgText = serializeSvg(svg)
  // Convert svg to PNG dataURL
  const blob = new Blob([svgText], { type: 'image/svg+xml;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const img = new Image()
  img.decoding = 'async'
  const loaded = new Promise<void>((resolve, reject) => {
    img.onload = () => resolve()
    img.onerror = () => reject(new Error('Cannot load SVG image'))
  })
  img.src = url
  await loaded
  URL.revokeObjectURL(url)

  const w = svg.clientWidth || 900
  const h = svg.clientHeight || 600
  const canvas = document.createElement('canvas')
  const scale = 2.5
  canvas.width = Math.floor(w * scale)
  canvas.height = Math.floor(h * scale)
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
  const pngDataUrl = canvas.toDataURL('image/png')

  const html = `
<html>
<head>
  <meta charset="utf-8" />
  <title>Smart Geometry Drawing</title>
</head>
<body style="font-family:Times New Roman,serif;">
  <h2>Smart Geometry Drawing</h2>
  <p><b>Hình vẽ:</b></p>
  <img src="${pngDataUrl}" style="max-width:100%;border:1px solid #ddd;" />
  <hr/>
  <p><b>DỮ KIỆN TRÍCH XUẤT</b> và <b>CHI TIẾT THỰC HIỆN</b> xem trong ứng dụng.</p>
</body>
</html>
  `.trim()

  const docBlob = new Blob([html], { type: 'application/msword' })
  downloadBlob(docBlob, filename)
}
