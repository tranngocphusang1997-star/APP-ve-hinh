import React from 'react'
import type { Tool } from '../types'

type Props = {
  tool: Tool
  onToolChange: (t: Tool) => void
  canUndo: boolean
  onUndo: () => void
  onClear: () => void
  showGrid: boolean
  onToggleGrid: (v: boolean) => void
  strokeWidth: number
  onStrokeWidth: (v: number) => void
  dashed: boolean
  onDashed: (v: boolean) => void
  color: string
  onColor: (v: string) => void
}

const tools: { id: Tool; label: string }[] = [
  { id: 'select', label: 'Chọn' },
  { id: 'point', label: 'Điểm' },
  { id: 'segment', label: 'Đoạn' },
  { id: 'line', label: 'Thẳng' },
  { id: 'circle', label: 'Tròn' },
  { id: 'arc', label: 'Cung' },
  { id: 'angle', label: 'Góc' },
  { id: 'note', label: 'Ghi' },
]

const palette = ['#1f5bff', '#ff4d4f', '#34c759', '#f5a623', '#6c5ce7', '#111111']

export default function RightPanel(props: Props) {
  const { tool, onToolChange, canUndo, onUndo, onClear, showGrid, onToggleGrid, strokeWidth, onStrokeWidth, dashed, onDashed, color, onColor } = props
  return (
    <div className="panel right">
      <h3>CÔNG CỤ VẼ</h3>
      <div className="card">
        <div className="toolGrid">
          {tools.map(t => (
            <button key={t.id} className={'tool ' + (tool === t.id ? 'active' : '')} onClick={() => onToolChange(t.id)}>
              {t.label}
            </button>
          ))}
        </div>
        <div style={{ height: 10 }} />
        <div className="row">
          <button className="btn" disabled={!canUndo} onClick={onUndo}>QUAY LẠI</button>
          <button className="btn danger" onClick={onClear}>XÓA HẾT</button>
        </div>
      </div>

      <h3>HỆ THỐNG</h3>
      <div className="card">
        <label className="kv">
          <span>Hiển thị lưới</span>
          <input type="checkbox" checked={showGrid} onChange={(e) => onToggleGrid(e.target.checked)} />
        </label>
      </div>

      <h3>TÙY CHỈNH NÉT</h3>
      <div className="card">
        <div className="label">Độ dày nét</div>
        <input
          type="range"
          min={1}
          max={6}
          step={1}
          value={strokeWidth}
          onChange={(e) => onStrokeWidth(Number(e.target.value))}
        />
        <div style={{ height: 10 }} />
        <label className="kv">
          <span>Nét đứt</span>
          <input type="checkbox" checked={dashed} onChange={(e) => onDashed(e.target.checked)} />
        </label>
        <div style={{ height: 10 }} />
        <div className="label">Màu sắc</div>
        <div className="palette">
          {palette.map(c => (
            <div
              key={c}
              className={'swatch ' + (c === color ? 'active' : '')}
              style={{ background: c }}
              onClick={() => onColor(c)}
              title={c}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
