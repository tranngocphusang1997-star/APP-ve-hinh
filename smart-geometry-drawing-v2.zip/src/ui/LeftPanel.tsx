import React, { useRef } from 'react'
import type { ChecklistItem } from '../types'

type Props = {
  text: string
  onTextChange: (v: string) => void
  onUploadImage: (file: File) => void
  onSolve: () => void
  checklist: ChecklistItem[]
  onPickChecklist: (item: ChecklistItem) => void
}

export default function LeftPanel(props: Props) {
  const { text, onTextChange, onUploadImage, onSolve, checklist, onPickChecklist } = props
  const fileRef = useRef<HTMLInputElement | null>(null)

  return (
    <div className="panel">
      <h3>PHÂN TÍCH ĐỀ BÀI</h3>

      <div className="card">
        <div className="label">Nội dung bài toán</div>
        <textarea value={text} onChange={(e) => onTextChange(e.target.value)} placeholder="Dán đề bài (có thể có LaTeX) vào đây..." />
        <div style={{ height: 10 }} />
        <div className="row">
          <button className="btn" onClick={() => fileRef.current?.click()}>Tải ảnh</button>
          <button className="btn primary" onClick={onSolve}>Xử lý &amp; Vẽ</button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="image/png,image/jpeg"
          style={{ display: 'none' }}
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) onUploadImage(f)
            e.currentTarget.value = ''
          }}
        />
        <div style={{ marginTop: 8, fontSize: 12, color: '#a7b0c0' }}>
          * MVP: OCR chưa tích hợp trong bản chạy thử này. Bạn có thể dán đề vào ô trên.
        </div>
      </div>

      <div className="card">
        <div className="label">DỮ KIỆN TRÍCH XUẤT</div>
        <div className="list">
          {checklist.map((it, idx) => (
            <div key={it.id} className="item" onClick={() => onPickChecklist(it)}>
              <div className="tag">{idx + 1}</div>
              <div className="txt">{it.text}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
