import React from 'react'
import type { StepItem } from '../types'

type Props = {
  steps: StepItem[]
  onPickStep: (s: StepItem) => void
}

export default function BottomPanel({ steps, onPickStep }: Props) {
  return (
    <div className="bottom">
      <h3>GIẢI BÀI TẬP CÙNG AI</h3>
      <div className="steps">
        <div style={{ fontSize: 12, color: '#a7b0c0', marginBottom: 8 }}>CHI TIẾT THỰC HIỆN</div>
        {steps.map((s, i) => (
          <div key={s.id} className="step" onClick={() => onPickStep(s)}>
            <div className="num">{i + 1}</div>
            <div className="txt">{s.text}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
