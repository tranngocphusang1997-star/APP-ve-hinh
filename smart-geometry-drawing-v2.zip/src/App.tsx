import React, { useMemo, useRef, useState } from 'react'
import type { ChecklistItem, Scene, StepItem, Tool } from './types'
import LeftPanel from './ui/LeftPanel'
import RightPanel from './ui/RightPanel'
import BottomPanel from './ui/BottomPanel'
import SvgCanvas from './render/SvgCanvas'
import { useHistory } from './state/useHistory'
import { solveFromText } from './engine/solver'
import { exportPngFromSvg, exportPdfFromSvg, exportWordHtmlFromSvg, getSvgElementById } from './export/exporters'
import { v } from './engine/geometry'

const DEFAULT_TEXT = `Cho đường tròn tâm $O$, đường kính $AB = 2R$, $M$ là một điểm nằm giữa $O$ và $A$ 
($M$ khác $O$ và khác $A$). Dây cung $CD$ của $(O)$ đi qua điểm $M$. Biết rằng
$CM=\\sqrt{56}\\,\\text{cm}$, $DM=12\\,\\text{cm}$, $\\widehat{AMC}=45^\\circ$,
$\\widehat{AOC}$ và $\\widehat{BOD}$ là các góc nhọn.`

function emptyScene(): Scene {
  return {
    points: {
      O: { id: 'O', label: 'O', p: v(0, 0) },
      A: { id: 'A', label: 'A', p: v(-10, 0) },
      B: { id: 'B', label: 'B', p: v(10, 0) }
    },
    primitives: [
      { id: 'circleO', type: 'circle', c: 'O', r: 10, stroke: '#1f5bff', strokeWidth: 2 },
      { id: 'AB', type: 'segment', a: 'A', b: 'B', stroke: '#1f5bff', strokeWidth: 2 }
    ]
  }
}

export default function App() {
  const [text, setText] = useState(DEFAULT_TEXT)
  const sceneHist = useHistory<Scene>(emptyScene())
  const [checklist, setChecklist] = useState<ChecklistItem[]>([])
  const [steps, setSteps] = useState<StepItem[]>([])
  const [warnings, setWarnings] = useState<string[]>([])
  const [highlightRefs, setHighlightRefs] = useState<Set<string>>(new Set())
  const [tool, setTool] = useState<Tool>('select')
  const [showGrid, setShowGrid] = useState(true)
  const [strokeWidth, setStrokeWidth] = useState(2)
  const [dashed, setDashed] = useState(false)
  const [color, setColor] = useState('#1f5bff')
  const [toast, setToast] = useState<string | null>(null)
  const fitRef = useRef<null | (() => void)>(null)

  const canUndo = sceneHist.canUndo

  function solve() {
    const res = solveFromText(text)
    sceneHist.set(res.scene)
    setChecklist(res.checklist)
    setSteps(res.steps)
    setWarnings(res.diagnostics.warnings)
    setHighlightRefs(new Set())
    setToast(res.diagnostics.warnings.length ? 'Có cảnh báo: xem góc trái dưới (toast).' : null)
  }

  function clearAll() {
    sceneHist.set(emptyScene())
    setChecklist([])
    setSteps([])
    setWarnings([])
    setHighlightRefs(new Set())
    setToast(null)
  }

  function onPickChecklist(it: ChecklistItem) {
    setHighlightRefs(new Set(it.refs))
  }
  function onPickStep(s: StepItem) {
    setHighlightRefs(new Set(s.refs))
  }

  async function doExportPng() {
    const svg = getSvgElementById('geom-svg')
    if (!svg) return
    await exportPngFromSvg(svg, 'diagram.png')
  }
  async function doExportPdf() {
    const svg = getSvgElementById('geom-svg')
    if (!svg) return
    await exportPdfFromSvg(svg, 'diagram.pdf')
  }
  async function doExportWord() {
    const svg = getSvgElementById('geom-svg')
    if (!svg) return
    await exportWordHtmlFromSvg(svg, 'diagram.doc')
  }

  function uploadImage(file: File) {
    // MVP: no OCR. We just inform the user.
    setToast('MVP chạy thử: OCR chưa tích hợp. Hãy dán đề vào ô “Nội dung bài toán”.')
    console.log('Image selected:', file.name, file.size)
  }

  return (
    <div className="app">
      <div className="topbar">
        <div className="brand">
          <div className="dot" />
          <div>Smart Geometry Drawing</div>
        </div>
        <div className="top-actions">
          <button className="btn" onClick={() => fitRef.current?.()}>Fit</button>
          <button className="btn" onClick={doExportWord}>TẢI WORD</button>
          <button className="btn" onClick={doExportPdf}>TẢI PDF</button>
          <button className="btn ok" onClick={doExportPng}>TẢI PNG</button>
        </div>
      </div>

      <div className="main">
        <LeftPanel
          text={text}
          onTextChange={setText}
          onUploadImage={uploadImage}
          onSolve={solve}
          checklist={checklist}
          onPickChecklist={onPickChecklist}
        />

        <div style={{ position: 'relative', minHeight: 0 }}>
          <SvgCanvas
            scene={sceneHist.present}
            tool={tool}
            highlightRefs={highlightRefs}
            showGrid={showGrid}
            strokeWidth={strokeWidth}
            dashed={dashed}
            color={color}
            onSceneChange={sceneHist.set}
            onToast={setToast}
            onFitRequest={(fitFn) => { fitRef.current = fitFn }}
          />
          {toast ? (
            <div className="toast">
              <div style={{ fontWeight: 700, marginBottom: 6 }}>Thông báo</div>
              <div>{toast}</div>
              {warnings.length ? (
                <div style={{ marginTop: 8, color: '#ffd2d2' }}>
                  {warnings.slice(0, 4).map((w, i) => <div key={i}>• {w}</div>)}
                </div>
              ) : null}
              <div style={{ marginTop: 8 }}>
                <button className="btn ghost" onClick={() => setToast(null)}>Đóng</button>
              </div>
            </div>
          ) : null}
        </div>

        <RightPanel
          tool={tool}
          onToolChange={setTool}
          canUndo={canUndo}
          onUndo={sceneHist.undo}
          onClear={clearAll}
          showGrid={showGrid}
          onToggleGrid={setShowGrid}
          strokeWidth={strokeWidth}
          onStrokeWidth={setStrokeWidth}
          dashed={dashed}
          onDashed={setDashed}
          color={color}
          onColor={setColor}
        />
      </div>

      <BottomPanel steps={steps} onPickStep={onPickStep} />
    </div>
  )
}
