import { normalizeLatexVietnamese } from './normalize'

export type Extracted = {
  normalizedText: string
  // for now we only extract the specialized pattern used in the user's problem
  a?: number // CM
  b?: number // DM
  angleAMC?: number // degrees
  hasCircleO?: boolean
  hasDiameterAB?: boolean
  hasMOnOA?: boolean
  hasChordCDThroughM?: boolean
  acuteAOC?: boolean
  acuteBOD?: boolean
  warnings: string[]
}

function parseNumberExpr(expr: string): number | null {
  // Supports: 12, 12.5, sqrt(56)
  const e = expr.trim()
  const mSqrt = e.match(/^sqrt\(([^)]+)\)$/i)
  if (mSqrt) {
    const inner = Number(mSqrt[1])
    if (Number.isFinite(inner)) return Math.sqrt(inner)
    return null
  }
  const num = Number(e)
  if (Number.isFinite(num)) return num
  return null
}

export function extractFromText(raw: string): Extracted {
  const warnings: string[] = []
  const t = normalizeLatexVietnamese(raw)

  const out: Extracted = {
    normalizedText: t,
    warnings
  }

  // Heuristics for this style of Vietnamese geometry problem
  out.hasCircleO = /đường tròn.*tâm\s*o/i.test(t) || /tâm\s*o/i.test(t)
  out.hasDiameterAB = /đường\s*kính\s*ab/i.test(t) || /ab\s*=\s*2r/i.test(t)
  out.hasMOnOA = /m\s*là\s*một\s*điểm\s*nằm\s*giữa\s*o\s*và\s*a/i.test(t) || /m\s*nằm\s*giữa\s*o\s*và\s*a/i.test(t)
  out.hasChordCDThroughM = /dây\s*cung\s*cd.*đi\s*qua\s*điểm\s*m/i.test(t) || /cd.*đi\s*qua\s*m/i.test(t)

  // CM and DM
  // Patterns: CM = sqrt(56) cm , DM = 12 cm
  const cm = t.match(/\bcm\s*=\s*(sqrt\([^\)]+\)|[0-9]+(?:\.[0-9]+)?)\b/i)
  if (cm) {
    const val = parseNumberExpr(cm[1])
    if (val != null) out.a = val
    else warnings.push('Không đọc được giá trị CM.')
  } else {
    // sometimes "CM=sqrt(56)"
    const cm2 = t.match(/\bcm\s*=\s*(sqrt\([^\)]+\)|[0-9]+(?:\.[0-9]+)?)\b/i)
    if (cm2) {
      const val = parseNumberExpr(cm2[1])
      if (val != null) out.a = val
    }
  }

  const dm = t.match(/\bdm\s*=\s*(sqrt\([^\)]+\)|[0-9]+(?:\.[0-9]+)?)\b/i)
  if (dm) {
    const val = parseNumberExpr(dm[1])
    if (val != null) out.b = val
    else warnings.push('Không đọc được giá trị DM.')
  } else {
    const dm2 = t.match(/\bdm\s*=\s*(sqrt\([^\)]+\)|[0-9]+(?:\.[0-9]+)?)\b/i)
    if (dm2) {
      const val = parseNumberExpr(dm2[1])
      if (val != null) out.b = val
    }
  }

  // angle AMC
  // normalized uses: "goc AMC=45°" or "goc AMC = 45°" or "AMC=45°"
  const ang = t.match(/goc\s*amc\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*°?/i) || t.match(/\bamc\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*°/i)
  if (ang) out.angleAMC = Number(ang[1])

  // acute angles
  out.acuteAOC = /goc\s*aoc.*nhọn/i.test(t) || /aoc.*góc\s*nhọn/i.test(t)
  out.acuteBOD = /goc\s*bod.*nhọn/i.test(t) || /bod.*góc\s*nhọn/i.test(t)

  // Validation
  if (!out.hasCircleO) warnings.push('Chưa chắc nhận ra “đường tròn tâm O”.')
  if (!out.hasDiameterAB) warnings.push('Chưa chắc nhận ra “đường kính AB = 2R”.')
  if (!out.hasMOnOA) warnings.push('Chưa chắc nhận ra “M nằm giữa O và A”.')
  if (!out.hasChordCDThroughM) warnings.push('Chưa chắc nhận ra “dây cung CD đi qua M”.')
  if (out.a == null) warnings.push('Thiếu CM.')
  if (out.b == null) warnings.push('Thiếu DM.')
  if (out.angleAMC == null) warnings.push('Thiếu góc AMC.')

  return out
}
