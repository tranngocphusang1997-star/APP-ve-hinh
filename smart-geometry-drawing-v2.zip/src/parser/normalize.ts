\
  // Normalize Vietnamese + LaTeX fragments into a parser-friendly plain text.
  export function normalizeLatexVietnamese(input: string): string {
    let s = input

    // Remove $...$ but keep content
    s = s.replace(/\$/g, '')

    // Replace common LaTeX macros
    s = s.replace(/\\sqrt\{([^}]+)\}/g, 'sqrt($1)')
    s = s.replace(/\\widehat\{([^}]+)\}/g, 'goc $1')
    s = s.replace(/\\text\{([^}]+)\}/g, '$1')
    s = s.replace(/\\,/g, ' ')
    s = s.replace(/\\;/g, ' ')
    s = s.replace(/\\!/g, '')
    s = s.replace(/\^\s*\\circ/g, '°')
    s = s.replace(/\^\s*\{\\circ\}/g, '°')

    // Clean extra TeX slashes that remain
    s = s.replace(/\\,/g, ' ')
    s = s.replace(/\\,/g, ' ')
    s = s.replace(/\\,/g, ' ')
    s = s.replace(/\\,/g, ' ')

    // Normalize unicode variants
    s = s.replace(/[“”]/g, '"')
    s = s.replace(/[’]/g, "'")

    // Collapse spaces
    s = s.replace(/\s+/g, ' ').trim()
    return s
  }
