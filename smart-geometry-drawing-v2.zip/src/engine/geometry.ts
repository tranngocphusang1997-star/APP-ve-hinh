import type { Vec2 } from '../types'

export const EPS = 1e-9

export function v(x: number, y: number): Vec2 { return { x, y } }
export function add(a: Vec2, b: Vec2): Vec2 { return { x: a.x + b.x, y: a.y + b.y } }
export function sub(a: Vec2, b: Vec2): Vec2 { return { x: a.x - b.x, y: a.y - b.y } }
export function mul(a: Vec2, k: number): Vec2 { return { x: a.x * k, y: a.y * k } }
export function dot(a: Vec2, b: Vec2): number { return a.x * b.x + a.y * b.y }
export function cross(a: Vec2, b: Vec2): number { return a.x * b.y - a.y * b.x }
export function len(a: Vec2): number { return Math.hypot(a.x, a.y) }
export function dist(a: Vec2, b: Vec2): number { return len(sub(a, b)) }
export function norm(a: Vec2): Vec2 {
  const L = len(a)
  if (L < EPS) return { x: 0, y: 0 }
  return { x: a.x / L, y: a.y / L }
}
export function angleBetween(u: Vec2, v2: Vec2): number {
  const nu = norm(u), nv = norm(v2)
  const c = Math.max(-1, Math.min(1, dot(nu, nv)))
  return Math.acos(c)
}
export function rot(a: Vec2, ang: number): Vec2 {
  const c = Math.cos(ang), s = Math.sin(ang)
  return { x: a.x * c - a.y * s, y: a.x * s + a.y * c }
}

export function degToRad(d: number): number { return d * Math.PI / 180 }
export function radToDeg(r: number): number { return r * 180 / Math.PI }

export function isAcuteAtOrigin(u: Vec2, v2: Vec2): boolean {
  // acute iff dot > 0
  return dot(u, v2) > 0
}

export function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n))
}
