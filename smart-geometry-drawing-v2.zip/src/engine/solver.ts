import type { SolveResult, Scene, ChecklistItem, StepItem } from '../types'
import { v, add, mul, sub, dot, isAcuteAtOrigin, degToRad, norm, rot, dist } from './geometry'
import { extractFromText } from '../parser/parser'

function uid(prefix: string) {
  return prefix + '_' + Math.random().toString(16).slice(2, 9)
}

function buildChecklist(): ChecklistItem[] {
  return [
    { id: 'c1', text: 'Đường tròn (O)', refs: ['circleO', 'O'] },
    { id: 'c2', text: 'Đường kính AB = 2R', refs: ['AB', 'A', 'B', 'O'] },
    { id: 'c3', text: 'M nằm giữa O và A', refs: ['M', 'OA'] },
    { id: 'c4', text: 'Dây CD đi qua M', refs: ['CD', 'C', 'D', 'M'] },
    { id: 'c5', text: 'CM = √56 cm', refs: ['C', 'M', 'segCM'] },
    { id: 'c6', text: 'DM = 12 cm', refs: ['D', 'M', 'segDM'] },
    { id: 'c7', text: '∠AMC = 45°', refs: ['A', 'M', 'C', 'arcAMC'] },
    { id: 'c8', text: '∠AOC, ∠BOD nhọn', refs: ['A', 'O', 'C', 'B', 'D', 'OC', 'OD'] },
  ]
}

function buildSteps(R: number, CM: number, DM: number, OM: number): StepItem[] {
  const fmt = (n: number) => {
    // pretty formatting
    const r = Math.round(n * 1e6) / 1e6
    return String(r)
  }
  return [
    { id: 's1', text: 'S1. Chuẩn hóa LaTeX và trích xuất dữ kiện từ đề.', refs: [] },
    { id: 's2', text: 'S2. Đặt hệ trục: O(0,0), AB là đường kính trên trục Ox.', refs: ['O', 'A', 'B', 'AB'] },
    { id: 's3', text: 'S3. Chọn hướng MC tạo với MA góc 45° (chọn phía trên).', refs: ['M', 'A', 'C', 'arcAMC'] },
    { id: 's4', text: `S4. Tính R = sqrt((CM^2 + DM^2)/2) = ${fmt(R)} và OM = (DM - CM)/sqrt(2) = ${fmt(OM)}.`, refs: ['O', 'M', 'circleO'] },
    { id: 's5', text: 'S5. Dựng M trên OA, dựng C và D theo công thức tọa độ, vẽ dây CD.', refs: ['M', 'OA', 'C', 'D', 'CD'] },
    { id: 's6', text: 'S6. Vẽ OC, OD và đánh dấu góc 45° tại M.', refs: ['OC', 'OD', 'arcAMC'] },
    { id: 's7', text: `Kiểm tra: CM=${fmt(CM)}, DM=${fmt(DM)} (cm).`, refs: ['segCM', 'segDM'] },
  ]
}

export function solveFromText(text: string): SolveResult {
  const ex = extractFromText(text)
  const warnings: string[] = [...ex.warnings]

  // Specialized solver for the exact pattern (the user’s problem).
  const a = ex.a
  const b = ex.b
  const angle = ex.angleAMC ?? 45

  if (a == null || b == null || Math.abs(angle - 45) > 1e-6) {
    // Fallback: draw a basic circle + diameter and stop
    const R = 10
    const scene: Scene = {
      points: {
        O: { id: 'O', label: 'O', p: v(0, 0) },
        A: { id: 'A', label: 'A', p: v(-R, 0) },
        B: { id: 'B', label: 'B', p: v(R, 0) },
      },
      primitives: [
        { id: 'circleO', type: 'circle', c: 'O', r: R, stroke: '#1f5bff', strokeWidth: 2 },
        { id: 'AB', type: 'segment', a: 'A', b: 'B', stroke: '#1f5bff', strokeWidth: 2 },
      ]
    }
    warnings.push('Không đủ dữ kiện để dựng đầy đủ (cần CM, DM và ∠AMC=45°).')
    return {
      scene,
      checklist: buildChecklist(),
      steps: buildSteps(R, a ?? 0, b ?? 0, 0),
      diagnostics: { warnings }
    }
  }

  // Coordinate geometry (as specified)
  // R^2 = (a^2 + b^2)/2
  const R = Math.sqrt((a * a + b * b) / 2)
  // m = (b - a)/sqrt(2) where M = (-m, 0) and 0<m<R
  const m = (b - a) / Math.sqrt(2)
  const OM = m

  if (!(m > 0 && m < R)) {
    warnings.push('Dữ kiện khiến M không nằm giữa O và A theo mô hình chuẩn. Vẫn cố dựng theo công thức.')
  }

  const O = v(0, 0)
  const A = v(-R, 0)
  const B = v(R, 0)
  const M = v(-m, 0)

  // direction u (135°) so C above AB
  const uUp = v(-Math.SQRT1_2, Math.SQRT1_2)
  const uDown = v(-Math.SQRT1_2, -Math.SQRT1_2)

  function buildWithU(u: {x:number;y:number}) {
    const C = add(M, mul(u, a))
    const D = sub(M, mul(u, b)) // D = M - b*u
    return { C, D }
  }

  let { C, D } = buildWithU(uUp)

  // acute checks: angle AOC acute means dot(OA, OC)>0 with OA=A-O, OC=C-O
  const OA = sub(A, O)
  const OB = sub(B, O)
  let OC = sub(C, O)
  let OD = sub(D, O)

  const okAcute = (c: any, d: any) => {
    const OC2 = sub(c, O)
    const OD2 = sub(d, O)
    const cond1 = isAcuteAtOrigin(OA, OC2)
    const cond2 = isAcuteAtOrigin(OB, OD2)
    return { cond1, cond2, ok: cond1 && cond2 }
  }

  let ac = okAcute(C, D)
  if (!ac.ok) {
    const alt = buildWithU(uDown)
    const ac2 = okAcute(alt.C, alt.D)
    if (ac2.ok || (!ac.ok && (ac2.cond1 && ac2.cond2))) {
      C = alt.C; D = alt.D; ac = ac2
    } else {
      // Prefer C above the diameter if both fail
      // keep C as uUp
    }
  }

  // Secondary fix: choose which of the two circle intersections corresponds to C and D
  // Ensure C is above x-axis by default
  if (C.y < D.y) {
    // keep C as the upper one
  }

  // Validate distances to circle (tolerant)
  const errC = Math.abs(dist(C, O) - R)
  const errD = Math.abs(dist(D, O) - R)
  if (errC > 1e-6 || errD > 1e-6) {
    warnings.push('Sai số dựng điểm trên đường tròn lớn hơn dự kiến (kiểm tra parser/đơn vị).')
  }

  // Build scene
  const scene: Scene = {
    points: {
      O: { id: 'O', label: 'O', p: O },
      A: { id: 'A', label: 'A', p: A },
      B: { id: 'B', label: 'B', p: B },
      M: { id: 'M', label: 'M', p: M },
      C: { id: 'C', label: 'C', p: C },
      D: { id: 'D', label: 'D', p: D },
    },
    primitives: [
      { id: 'circleO', type: 'circle', c: 'O', r: R, stroke: '#1f5bff', strokeWidth: 2 },
      { id: 'AB', type: 'segment', a: 'A', b: 'B', stroke: '#1f5bff', strokeWidth: 2 },
      { id: 'OA', type: 'segment', a: 'O', b: 'A', stroke: '#1f5bff', strokeWidth: 1, dashed: true },
      { id: 'OB', type: 'segment', a: 'O', b: 'B', stroke: '#1f5bff', strokeWidth: 1, dashed: true },
      { id: 'CD', type: 'segment', a: 'C', b: 'D', stroke: '#1f5bff', strokeWidth: 2 },
      { id: 'OC', type: 'segment', a: 'O', b: 'C', stroke: '#1f5bff', strokeWidth: 1, dashed: true },
      { id: 'OD', type: 'segment', a: 'O', b: 'D', stroke: '#1f5bff', strokeWidth: 1, dashed: true },
      { id: 'segCM', type: 'segment', a: 'C', b: 'M', stroke: '#1f5bff', strokeWidth: 2, label: 'CM = √56 cm', labelPos: 0.55 },
      { id: 'segDM', type: 'segment', a: 'D', b: 'M', stroke: '#1f5bff', strokeWidth: 2, label: 'DM = 12 cm', labelPos: 0.55 },
      // Angle arc at M for ∠AMC = 45°
      ...(() => {
        const MA = sub(A, M)
        const MC = sub(C, M)
        // base angles in world coords
        const angA = Math.atan2(MA.y, MA.x)
        const angC = Math.atan2(MC.y, MC.x)
        // we want the smaller arc from MA to MC (counterclockwise)
        // normalize
        let start = angA
        let end = angC
        const normAng = (x: number) => {
          while (x < -Math.PI) x += 2*Math.PI
          while (x > Math.PI) x -= 2*Math.PI
          return x
        }
        start = normAng(start); end = normAng(end)
        // compute delta
        let delta = end - start
        while (delta < 0) delta += 2*Math.PI
        while (delta > 2*Math.PI) delta -= 2*Math.PI
        // if delta too big, swap direction
        if (delta > Math.PI) {
          const tmp = start
          start = end
          end = tmp
        }
        const rArc = R * 0.18
        return [{
          id: 'arcAMC',
          type: 'arc' as const,
          center: 'M',
          r: rArc,
          startAngle: start,
          endAngle: end,
          stroke: '#1f5bff',
          strokeWidth: 2,
          label: '45°'
        }]
      })(),
    ]
  }

  return {
    scene,
    checklist: buildChecklist(),
    steps: buildSteps(R, a, b, OM),
    diagnostics: { warnings }
  }
}
