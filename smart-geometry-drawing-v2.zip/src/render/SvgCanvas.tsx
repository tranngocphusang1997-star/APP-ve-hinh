import React, { useEffect, useMemo, useRef, useState } from 'react'
import type { Scene, Tool, Vec2, Primitive } from '../types'
import { add, sub, mul, dist, v } from '../engine/geometry'

type Props = {
  scene: Scene
  tool: Tool
  highlightRefs: Set<string>
  showGrid: boolean
  strokeWidth: number
  dashed: boolean
  color: string
  onSceneChange?: (next: Scene) => void
  onToast?: (msg: string | null) => void
  onFitRequest?: (fit: () => void) => void
}

type Viewport = { scale: number; tx: number; ty: number } // screen transform applied to world

function worldToScreen(p: Vec2, vp: Viewport): Vec2 {
  return { x: p.x * vp.scale + vp.tx, y: p.y * vp.scale + vp.ty }
}
function screenToWorld(p: Vec2, vp: Viewport): Vec2 {
  return { x: (p.x - vp.tx) / vp.scale, y: (p.y - vp.ty) / vp.scale }
}

function computeBounds(scene: Scene) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (const pt of Object.values(scene.points)) {
    minX = Math.min(minX, pt.p.x); minY = Math.min(minY, pt.p.y)
    maxX = Math.max(maxX, pt.p.x); maxY = Math.max(maxY, pt.p.y)
  }
  for (const pr of scene.primitives) {
    if (pr.type === 'circle') {
      const c = scene.points[pr.c]?.p
      if (!c) continue
      minX = Math.min(minX, c.x - pr.r); minY = Math.min(minY, c.y - pr.r)
      maxX = Math.max(maxX, c.x + pr.r); maxY = Math.max(maxY, c.y + pr.r)
    }
    if (pr.type === 'arc') {
      const c = scene.points[pr.center]?.p
      if (!c) continue
      minX = Math.min(minX, c.x - pr.r); minY = Math.min(minY, c.y - pr.r)
      maxX = Math.max(maxX, c.x + pr.r); maxY = Math.max(maxY, c.y + pr.r)
    }
  }
  if (!Number.isFinite(minX)) return { minX: -10, minY: -10, maxX: 10, maxY: 10 }
  return { minX, minY, maxX, maxY }
}

function goldenFit(scene: Scene, w: number, h: number): Viewport {
  const b = computeBounds(scene)
  const bw = Math.max(1e-6, b.maxX - b.minX)
  const bh = Math.max(1e-6, b.maxY - b.minY)
  const margin = 40
  const scale = Math.min((w - margin * 2) / bw, (h - margin * 2) / bh)

  // target center in screen coords near golden ratio line
  const target = { x: 0.618 * w, y: 0.5 * h }
  const centerWorld = { x: (b.minX + b.maxX) / 2, y: (b.minY + b.maxY) / 2 }
  const centerScreen = { x: centerWorld.x * scale, y: centerWorld.y * scale }
  const tx = target.x - centerScreen.x
  const ty = target.y - centerScreen.y
  return { scale, tx, ty }
}

function svgArcPath(cx: number, cy: number, r: number, a0: number, a1: number): string {
  const x0 = cx + r * Math.cos(a0)
  const y0 = cy + r * Math.sin(a0)
  const x1 = cx + r * Math.cos(a1)
  const y1 = cy + r * Math.sin(a1)
  let delta = a1 - a0
  while (delta < 0) delta += Math.PI * 2
  while (delta > Math.PI * 2) delta -= Math.PI * 2
  const large = delta > Math.PI ? 1 : 0
  const sweep = 1
  return `M ${x0} ${y0} A ${r} ${r} 0 ${large} ${sweep} ${x1} ${y1}`
}

export default function SvgCanvas(props: Props) {
  const { scene, tool, highlightRefs, showGrid, strokeWidth, dashed, color, onSceneChange, onToast, onFitRequest } = props
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const [vp, setVp] = useState<Viewport>({ scale: 24, tx: 480, ty: 320 })
  const [isPanning, setIsPanning] = useState(false)
  const [lastMouse, setLastMouse] = useState<Vec2 | null>(null)
  const [pendingPoint, setPendingPoint] = useState<string | null>(null) // for 2-click tools
  const [draggingPoint, setDraggingPoint] = useState<string | null>(null)

  useEffect(() => {
    if (!wrapRef.current) return
    const rect = wrapRef.current.getBoundingClientRect()
    setVp(goldenFit(scene, rect.width, rect.height))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scene])

  useEffect(() => {
    if (!onFitRequest) return
    onFitRequest(() => {
      if (!wrapRef.current) return
      const rect = wrapRef.current.getBoundingClientRect()
      setVp(goldenFit(scene, rect.width, rect.height))
    })
  }, [onFitRequest, scene])

  const grid = useMemo(() => {
    if (!showGrid) return null
    // simple grid in screen coords
    const step = 40
    const lines: JSX.Element[] = []
    const W = 2000, H = 2000
    for (let x = 0; x <= W; x += step) {
      lines.push(<line key={'gx'+x} x1={x} y1={0} x2={x} y2={H} stroke="rgba(0,0,0,0.06)" strokeWidth={1} />)
    }
    for (let y = 0; y <= H; y += step) {
      lines.push(<line key={'gy'+y} x1={0} y1={y} x2={W} y2={y} stroke="rgba(0,0,0,0.06)" strokeWidth={1} />)
    }
    return <g>{lines}</g>
  }, [showGrid])

  const wSize = useMemo(() => {
    if (!wrapRef.current) return { w: 900, h: 600 }
    const r = wrapRef.current.getBoundingClientRect()
    return { w: r.width, h: r.height }
  }, [wrapRef.current])

  function getMouseWorld(e: React.MouseEvent): Vec2 {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
    const sx = e.clientX - rect.left
    const sy = e.clientY - rect.top
    return screenToWorld({ x: sx, y: sy }, vp)
  }

  function onWheel(e: React.WheelEvent) {
    e.preventDefault()
    if (!wrapRef.current) return
    const rect = wrapRef.current.getBoundingClientRect()
    const sx = e.clientX - rect.left
    const sy = e.clientY - rect.top
    const mouseW = screenToWorld({ x: sx, y: sy }, vp)
    const zoom = Math.exp(-e.deltaY * 0.0015)
    const nextScale = Math.max(5, Math.min(400, vp.scale * zoom))
    const nextTx = sx - mouseW.x * nextScale
    const nextTy = sy - mouseW.y * nextScale
    setVp({ scale: nextScale, tx: nextTx, ty: nextTy })
  }

  function hitTestPoint(world: Vec2): string | null {
    // pick nearest point within radius in screen space
    const threshPx = 10
    let best: { id: string; d: number } | null = null
    for (const pt of Object.values(scene.points)) {
      const sp = worldToScreen(pt.p, vp)
      const sw = worldToScreen(world, vp)
      const d = Math.hypot(sp.x - sw.x, sp.y - sw.y)
      if (d <= threshPx && (!best || d < best.d)) best = { id: pt.id, d }
    }
    return best?.id ?? null
  }

  function applyAddPoint(world: Vec2) {
    if (!onSceneChange) return
    const id = 'P' + Math.random().toString(16).slice(2, 7)
    const label = id.toUpperCase()
    const next = {
      ...scene,
      points: {
        ...scene.points,
        [id]: { id, label, p: world, draggable: true }
      }
    }
    onSceneChange(next)
  }

  function addSegment(aId: string, bId: string) {
    if (!onSceneChange) return
    const next = {
      ...scene,
      primitives: [
        ...scene.primitives,
        { id: 'seg_' + Math.random().toString(16).slice(2, 7), type: 'segment', a: aId, b: bId, stroke: color, strokeWidth, dashed }
      ]
    }
    onSceneChange(next)
  }

  function addCircle(centerId: string, pointId: string) {
    if (!onSceneChange) return
    const c = scene.points[centerId]?.p
    const p = scene.points[pointId]?.p
    if (!c || !p) return
    const r = dist(c, p)
    const next = {
      ...scene,
      primitives: [
        ...scene.primitives,
        { id: 'cir_' + Math.random().toString(16).slice(2, 7), type: 'circle', c: centerId, r, stroke: color, strokeWidth, dashed }
      ]
    }
    onSceneChange(next)
  }

  function onMouseDown(e: React.MouseEvent) {
    if (e.button !== 0) return
    const world = getMouseWorld(e)

    if (tool === 'select') {
      // pan with drag on empty area; drag point if hit
      const hit = hitTestPoint(world)
      if (hit) {
        setDraggingPoint(hit)
        setLastMouse(world)
        return
      }
      setIsPanning(true)
      setLastMouse({ x: e.clientX, y: e.clientY })
      return
    }

    if (tool === 'point') {
      applyAddPoint(world)
      onToast?.('Đã thêm điểm (tool Point).')
      return
    }

    if (tool === 'segment') {
      const hit = hitTestPoint(world)
      if (!hit) {
        onToast?.('Hãy click đúng vào một điểm để chọn đầu mút đoạn thẳng.')
        return
      }
      if (!pendingPoint) {
        setPendingPoint(hit)
        onToast?.('Chọn điểm thứ 2 để vẽ đoạn thẳng.')
      } else {
        if (pendingPoint !== hit) addSegment(pendingPoint, hit)
        setPendingPoint(null)
        onToast?.(null)
      }
      return
    }

    if (tool === 'circle') {
      const hit = hitTestPoint(world)
      if (!hit) {
        onToast?.('Hãy click điểm tâm và điểm trên đường tròn (đã có).')
        return
      }
      if (!pendingPoint) {
        setPendingPoint(hit)
        onToast?.('Chọn điểm thứ 2 để xác định bán kính đường tròn.')
      } else {
        if (pendingPoint !== hit) addCircle(pendingPoint, hit)
        setPendingPoint(null)
        onToast?.(null)
      }
      return
    }
  }

  function onMouseMove(e: React.MouseEvent) {
    if (draggingPoint && lastMouse && onSceneChange) {
      const world = getMouseWorld(e)
      const pt = scene.points[draggingPoint]
      if (!pt) return
      const next = {
        ...scene,
        points: {
          ...scene.points,
          [draggingPoint]: { ...pt, p: world }
        }
      }
      onSceneChange(next)
      return
    }
    if (isPanning && lastMouse) {
      const dx = e.clientX - lastMouse.x
      const dy = e.clientY - lastMouse.y
      setVp(vp => ({ ...vp, tx: vp.tx + dx, ty: vp.ty + dy }))
      setLastMouse({ x: e.clientX, y: e.clientY })
    }
  }

  function onMouseUp() {
    setIsPanning(false)
    setLastMouse(null)
    setDraggingPoint(null)
  }

  function renderPrimitive(pr: Primitive) {
    const hl = highlightRefs.has(pr.id)
    const stroke = (pr as any).stroke ?? '#1f5bff'
    const sw = ((pr as any).strokeWidth ?? 2) + (hl ? 2 : 0)
    const dash = ((pr as any).dashed ?? false) ? '6 6' : undefined

    if (pr.type === 'segment') {
      const a = scene.points[pr.a]?.p
      const b = scene.points[pr.b]?.p
      if (!a || !b) return null
      const mid = add(a, mul(sub(b, a), pr.labelPos ?? 0.5))
      return (
        <g key={pr.id} data-id={pr.id}>
          <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={hl ? '#ff4d4f' : stroke} strokeWidth={sw} strokeDasharray={dash} />
          {pr.label ? (
            <text x={mid.x} y={mid.y} fontSize={0.6} fill={hl ? '#ff4d4f' : '#1f5bff'}>
              {pr.label}
            </text>
          ) : null}
        </g>
      )
    }
    if (pr.type === 'circle') {
      const c = scene.points[pr.c]?.p
      if (!c) return null
      return (
        <circle key={pr.id} data-id={pr.id} cx={c.x} cy={c.y} r={pr.r} fill="none" stroke={hl ? '#ff4d4f' : stroke} strokeWidth={sw} strokeDasharray={dash} />
      )
    }
    if (pr.type === 'arc') {
      const c = scene.points[pr.center]?.p
      if (!c) return null
      const d = svgArcPath(c.x, c.y, pr.r, pr.startAngle, pr.endAngle)
      // label at mid angle
      const midAng = (pr.startAngle + pr.endAngle) / 2
      const lp = { x: c.x + pr.r * 1.15 * Math.cos(midAng), y: c.y + pr.r * 1.15 * Math.sin(midAng) }
      return (
        <g key={pr.id} data-id={pr.id}>
          <path d={d} fill="none" stroke={hl ? '#ff4d4f' : stroke} strokeWidth={sw} strokeDasharray={dash} />
          {pr.label ? (
            <text x={lp.x} y={lp.y} fontSize={0.75} fill={hl ? '#ff4d4f' : '#1f5bff'}>
              {pr.label}
            </text>
          ) : null}
        </g>
      )
    }
    if (pr.type === 'note') {
      const p = scene.points[pr.at]?.p
      if (!p) return null
      return (
        <text key={pr.id} data-id={pr.id} x={p.x} y={p.y} fontSize={0.8} fill={hl ? '#ff4d4f' : '#1f5bff'}>
          {pr.text}
        </text>
      )
    }
    return null
  }

  const pointsEls = useMemo(() => {
    const els: JSX.Element[] = []
    for (const pt of Object.values(scene.points)) {
      const hl = highlightRefs.has(pt.id)
      els.push(
        <g key={pt.id} data-id={pt.id}>
          <circle cx={pt.p.x} cy={pt.p.y} r={0.18} fill={hl ? '#ff4d4f' : '#0d1220'} stroke={hl ? '#ff4d4f' : '#1f5bff'} strokeWidth={hl ? 0.14 : 0.1} />
          <text x={pt.p.x + 0.28} y={pt.p.y - 0.28} fontSize={0.85} fill={hl ? '#ff4d4f' : '#0d1220'} stroke="none">
            {pt.label}
          </text>
        </g>
      )
    }
    return els
  }, [scene.points, highlightRefs])

  const zoomText = Math.round(vp.scale / 24 * 100)

  return (
    <div ref={wrapRef} className="canvasWrap">
      <div className="canvasHud">
        <div className="pill">Zoom: {zoomText}%</div>
        {tool === 'select' ? <div className="pill">Giữ chuột trái để di chuyển (Pan)</div> : <div className="pill">Tool: {tool}</div>}
      </div>

      <svg
        id="geom-svg"
        width="100%"
        height="100%"
        viewBox={`0 0 ${wSize.w || 900} ${wSize.h || 600}`}
        onWheel={onWheel}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        style={{ display: 'block' }}
      >
        {/* Grid in screen space */}
        {showGrid ? (
          <g transform="translate(0,0)">
            {grid}
          </g>
        ) : null}

        {/* World content */}
        <g transform={`translate(${vp.tx},${vp.ty}) scale(${vp.scale})`}>
          {scene.primitives.map(renderPrimitive)}
          {pointsEls}
        </g>
      </svg>

    </div>
  )
}
