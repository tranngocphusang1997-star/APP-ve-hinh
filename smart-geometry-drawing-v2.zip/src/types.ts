export type Vec2 = { x: number; y: number }

export type Point = {
  id: string
  label: string
  p: Vec2
  draggable?: boolean
}

export type Segment = {
  id: string
  type: 'segment'
  a: string // point id
  b: string // point id
  stroke?: string
  strokeWidth?: number
  dashed?: boolean
  label?: string
  labelPos?: number // 0..1
}

export type Circle = {
  id: string
  type: 'circle'
  c: string // center point id
  r: number
  stroke?: string
  strokeWidth?: number
  dashed?: boolean
}

export type Arc = {
  id: string
  type: 'arc'
  center: string // point id
  r: number
  startAngle: number // radians
  endAngle: number // radians
  stroke?: string
  strokeWidth?: number
  dashed?: boolean
  label?: string
}

export type Note = {
  id: string
  type: 'note'
  at: string // point id
  text: string
}

export type Primitive = Segment | Circle | Arc | Note

export type ChecklistItem = {
  id: string
  text: string
  refs: string[]
}

export type StepItem = {
  id: string
  text: string
  refs: string[]
}

export type Scene = {
  points: Record<string, Point>
  primitives: Primitive[]
}

export type SolveResult = {
  scene: Scene
  checklist: ChecklistItem[]
  steps: StepItem[]
  diagnostics: { warnings: string[] }
}

export type Tool =
  | 'select'
  | 'point'
  | 'segment'
  | 'line'
  | 'circle'
  | 'arc'
  | 'angle'
  | 'note'
